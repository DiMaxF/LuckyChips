package com.oleg2013.casino

class Variables {

    companion object{
        var music: Boolean = true
        var sounds: Boolean = true
        var vibration: Boolean = true
        var quiet_mode: Boolean = false
    }


}